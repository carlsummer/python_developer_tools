# -*- encoding: utf-8 -*-
'''
@File    :   predict_sh.py    
@Contact :   whut.hexin@foxmail.com
@License :   (C)Copyright 2017-2020, HeXin

@Modify Time      @Author    @Version    @Desciption
------------      -------    --------    -----------
2020/10/16 20:44   xin      1.0         None
'''

import os

# os.system('python predict_demo.py --config_file configs/wc_seg_res_unet_r34_ibn_a_160e.yml '
#           '--rs_img_file /media/dell/E2DE40E3DE40B219/test_samples/largeimg/0.tif '
#           '--temp_img_save_path /media/dell/E2DE40E3DE40B219/test_samples/largeimg/clip_temp0 '
#           '--temp_seg_map_save_path /media/dell/E2DE40E3DE40B219/test_samples/largeimg/seg_temp0  '
#           '--save_seg_map_file /media/dell/E2DE40E3DE40B219/test_samples/largeimg/res_gray1/res0.tif')
#
