import os

os.system('python inference.py --config_file configs/wc_unet.yml')